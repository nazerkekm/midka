//
//  DetailViewController.swift
//  Alarm
//
//  Created by Назерке on 10/20/20.
//  Copyright © 2020 Nazerke Koishybayeva. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var hours: Date!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
